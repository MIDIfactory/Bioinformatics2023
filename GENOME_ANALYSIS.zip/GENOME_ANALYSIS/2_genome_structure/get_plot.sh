echo 1234 | sudo -S apt install gnuplot-x11
gnuplot out.gp
