rm -r /home/chewbe/miniconda/bin/prodigal
echo 1234 | sudo -S apt install prodigal
