pip install mummer-idotplot
mummer-idotplot output.mums out.html --refs CMycoplasma_bovis_PG45 --querys Mycoplasma_bovis_MBG
open out.html
