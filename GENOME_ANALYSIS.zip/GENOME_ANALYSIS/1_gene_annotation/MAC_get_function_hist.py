import os, sys
os.system("pip install matplotlib")
os.system("conda install python.app")
import matplotlib.pyplot as plt
import numpy as np


inF = open(sys.argv[1].strip(), "r") # BLASTp output
tabF = open("fun2003-2014.tab","r")

hashF={}  # Codes Table reading
for line in tabF.readlines():
        if line[0]!="#":
                hashF[line.strip().split("\t")[0]]=line.strip().split("\t")[1]


hash={} #Count the number of aa for each category

for line in inF.readlines():
        let=line.strip().split("|")[1]


        if len(let)==1:
                kk=hashF[let]
                #print kk
                if kk not in hash.keys():
                        hash[kk]=0
                hash[kk]+=1

print(hash)
names = list(hash.keys())
values = list(hash.values())
plt.bar(range(len(hash)), values, tick_label=names)
plt.xticks(rotation = 90)
#plt.ticks(X, hash.keys(), rotation='vertical')
#ymax = max(hash.values()) + 20
#plt.ylim(0, ymax)
plt.savefig('functions.png', bbox_inches="tight")




