rm -r /home/chewbe/miniconda3/bin/prodigal
echo 1234 | sudo -S apt install prodigal
